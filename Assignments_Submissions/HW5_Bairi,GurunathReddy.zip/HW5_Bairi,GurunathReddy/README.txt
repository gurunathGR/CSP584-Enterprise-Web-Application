Read me -

Steps - 
1. Copy the project in Apache tomcat folder
2. Install and configure MYSQL and mongo DB
3. Run the below My SQl and Mongo DB queries -

MySql query -
use ExampleDatabase5;

create table CustomerOrders
(
OrderId integer,
userName varchar(40),
orderName varchar(40),
orderPrice double,
userAddress varchar(40),
creditCardNo varchar(40),
primary key(OrderId, userName, orderName)
);


select * from Registration;	
select * from CustomerOrders;
select * from Productdetails;


create table Productdetails
(
ProductType varchar(40),
Id varchar(40),
productName varchar(40),
productPrice double,
productImage varchar(40),
productDiscount double,
primary key(Id)
);


Create table Products
(
id varchar(40),
name varchar(40),
price double,
quantity int,
OnSale varchar(40),
Rebate varchar(40)

);

create table CustomerOrders
(
OrderId integer,
userName varchar(40),
orderName varchar(40),
orderPrice double,
userAddress varchar(40),
creditCardNo varchar(40),
date_place varchar(40),
primary key(OrderId, userName, orderName)
);



MongoDb Query - 
use CustomerReviews
db.myReviews.find()

For deal matches and Recommendation system :

To get connected to twitter : Make sure the credentials.txt file is in directory. And then python notebooks can be executed and 
generate required text and excel files. 


5. Compile the class file and run the application in tomcat server



//Note -
MongoDB, MYSQL and Apache server should be up and running in order to run the application
