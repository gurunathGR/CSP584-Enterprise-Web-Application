import java.sql.*;
import java.util.*;
                	
public class MySqlDataStoreUtilities
{
static Connection conn = null;
static String message;
public static void getConnection()
{

	try
	{
	Class.forName("com.mysql.jdbc.Driver").newInstance();
	conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/exampledatabase5","root","root");							
	}
	catch(Exception e)
	{
		System.out.println("MYSQL Connection Error" + e);
	
	}
}


public static void deleteOrder(int orderId,String orderName)
{
	try
	{
		
		getConnection();
		String deleteOrderQuery ="Delete from customerorders where OrderId=? and orderName=?";
		PreparedStatement pst = conn.prepareStatement(deleteOrderQuery);
		pst.setInt(1,orderId);
		pst.setString(2,orderName);
		pst.executeUpdate();
	}
	catch(Exception e)
	{
			
	}
}

public static void insertOrder(int orderId,String userName,String orderName,double orderPrice,String userAddress,String creditCardNo,String date_place)
{
	try
	{
	
		getConnection();
		
		String insertIntoCustomerOrderQuery = "INSERT INTO customerOrders(OrderId,UserName,OrderName,OrderPrice,userAddress,creditCardNo,date_place) "
		+ "VALUES (?,?,?,?,?,?,?);";	
			
		PreparedStatement pst = conn.prepareStatement(insertIntoCustomerOrderQuery);
		//set the parameter for each column and execute the prepared statement
		pst.setInt(1,orderId);
		pst.setString(2,userName);
		pst.setString(3,orderName);
		pst.setDouble(4,orderPrice);
		pst.setString(5,userAddress);
		pst.setString(6,creditCardNo);
		pst.setString(7,date_place);
		pst.execute();
	}
	catch(Exception e)
	{
	
	}		
}

public static HashMap<Integer, ArrayList<OrderPayment>> selectOrder()
{	

	HashMap<Integer, ArrayList<OrderPayment>> orderPayments=new HashMap<Integer, ArrayList<OrderPayment>>();
		
	try
	{					

		getConnection();
		String selectOrderQuery ="select * from customerorders";			
		PreparedStatement pst = conn.prepareStatement(selectOrderQuery);
		ResultSet rs = pst.executeQuery();	
		ArrayList<OrderPayment> orderList=new ArrayList<OrderPayment>();
		while(rs.next())
		{
			if(!orderPayments.containsKey(rs.getInt("OrderId")))
			{	
				ArrayList<OrderPayment> arr = new ArrayList<OrderPayment>();
				orderPayments.put(rs.getInt("orderId"), arr);
			}
			ArrayList<OrderPayment> listOrderPayment = orderPayments.get(rs.getInt("OrderId"));		
			System.out.println("data is"+rs.getInt("OrderId")+orderPayments.get(rs.getInt("OrderId")));

			//add to orderpayment hashmap
			//OrderPayment order= new OrderPayment(rs.getInt("OrderId"),rs.getString("userName"),rs.getString("orderName"),rs.getDouble("orderPrice"),rs.getString("userAddress"),rs.getString("creditCardNo"),rs.getString("date_place"));
			
			OrderPayment order= new OrderPayment(rs.getInt("OrderId"),rs.getString("userName"),rs.getString("orderName"),rs.getDouble("orderPrice"),rs.getString("userAddress"),rs.getString("creditCardNo"));
			
			listOrderPayment.add(order);
					
		}
				
					
	}
	catch(Exception e)
	{
		
	}
	return orderPayments;
}


public static void insertUser(String username,String password,String repassword,String usertype)
{
	try
	{	

		getConnection();
		String insertIntoCustomerRegisterQuery = "INSERT INTO Registration(username,password,repassword,usertype) "
		+ "VALUES (?,?,?,?);";	
	
				
		PreparedStatement pst = conn.prepareStatement(insertIntoCustomerRegisterQuery);
		pst.setString(1,username);
		pst.setString(2,password);
		pst.setString(3,repassword);
		pst.setString(4,usertype);
		pst.execute();
		
		System.out.println("Inside InsertUSer");
	}
	catch(Exception e)
	{
		System.out.println("Execption Inside InsertUSer");
	}	
}

public static HashMap<String,User> selectUser()
{	
	HashMap<String,User> hm=new HashMap<String,User>();
	try 
	{
		getConnection();
		Statement stmt=conn.createStatement();
		String selectCustomerQuery="select * from  Registration";
		ResultSet rs = stmt.executeQuery(selectCustomerQuery);
		while(rs.next())
		{	User user = new User(rs.getString("username"),rs.getString("password"),rs.getString("usertype"));
				hm.put(rs.getString("username"), user);
		}
	}
	catch(Exception e)
	{
	}
	return hm;			
}



public static void Insertproducts()
{
	try{
		
		getConnection();
		String truncatetableacc = "delete from Product_accessories;";
		PreparedStatement pstt = conn.prepareStatement(truncatetableacc);
		pstt.executeUpdate();
		System.out.println("Insert Product function");
		
		String truncatetableprod = "delete from  Productdetails;";
		PreparedStatement psttprod = conn.prepareStatement(truncatetableprod);
		psttprod.executeUpdate();	
		
		System.out.println("Insert Product function after product details delete");
		
		
		String insertProductQurey = "INSERT INTO  Productdetails(ProductType,Id,productName,productPrice,productImage,productDiscount)" +
		"VALUES (?,?,?,?,?,?);";
		
		System.out.println("Insert insert Product query");
		
		/**for(Map.Entry<String,Laptops> entry : SaxParserDataStore.laptop.entrySet())
		{   
			String name = "laptop";
	        Laptops acc = entry.getValue();
			
			PreparedStatement pst = conn.prepareStatement(insertProductQurey);
			pst.setString(1,name);
			pst.setString(2,acc.getId());
			pst.setString(3,acc.getName());
			pst.setDouble(4,acc.getPrice());
			pst.setString(5,acc.getImage());
			// pst.setString(6,acc.getRetailer());
			// pst.setString(7,acc.getCondition());
			pst.setDouble(6,acc.getDiscount());
			
			pst.executeUpdate();
			System.out.println("Insert insert Laptop query");
			
			
		} */
		
		for(Map.Entry<String,Laptop> entry : SaxParserDataStore.laptop.entrySet())
		{   
			String name = "laptops";
	        Laptop acc = entry.getValue();
			
			PreparedStatement pst = conn.prepareStatement(insertProductQurey);
			pst.setString(1,name);
			pst.setString(2,acc.getId());
			pst.setString(3,acc.getName());
			pst.setDouble(4,acc.getPrice());
			pst.setString(5,acc.getImage());
		//	pst.setString(6,acc.getRetailer());
			//pst.setString(7,acc.getCondition());
			pst.setDouble(8,acc.getDiscount());
			//pst.setInt(9,acc.getCount());
			pst.executeUpdate();
			
			
		}
		
		for(Map.Entry<String,Phones> entry : SaxParserDataStore.phone.entrySet())
		{   
	        Phones con = entry.getValue();
			String name = "phone";
			
						
			
			PreparedStatement pst = conn.prepareStatement(insertProductQurey);
			pst.setString(1,name);
			pst.setString(2,con.getId());
			pst.setString(3,con.getName());
			pst.setDouble(4,con.getPrice());
			pst.setString(5,con.getImage());
			// pst.setString(6,con.getRetailer());
			// pst.setString(7,con.getCondition());
			pst.setDouble(6,con.getDiscount());
			
			pst.executeUpdate();
			 try{
			 HashMap<String,String> acc = con.getAccessories();
			 String insertAccessoryQurey = "INSERT INTO  Product_accessories(productName,accessoriesName)" +
			 "VALUES (?,?);";
			 for(Map.Entry<String,String> accentry : acc.entrySet())
			 {
				 PreparedStatement pstacc = conn.prepareStatement(insertAccessoryQurey);
				 pstacc.setString(1,con.getId());
				 pstacc.setString(2,accentry.getValue());
				 pstacc.executeUpdate();
			 }
			 }catch(Exception et){
				 et.printStackTrace();
			 }
		}
		for(Map.Entry<String,SmartSpeaker> entry : SaxParserDataStore.smartspeaker.entrySet())
		{   
			String name = "smartspeaker";
	        SmartSpeaker smartspeaker = entry.getValue();
			
			PreparedStatement pst = conn.prepareStatement(insertProductQurey);
			pst.setString(1,name);
			pst.setString(2,smartspeaker.getId());
			pst.setString(3,smartspeaker.getName());
			pst.setDouble(4,smartspeaker.getPrice());
			pst.setString(5,smartspeaker.getImage());
			// pst.setString(6,smartspeaker.getRetailer());
			// pst.setString(7,smartspeaker.getCondition());
			pst.setDouble(6,smartspeaker.getDiscount());
			
			pst.executeUpdate();
			
			
		}
		for(Map.Entry<String,WearableTechnology> entry : SaxParserDataStore.wearabletechnology.entrySet())
		{   
			String name = "wearabletechnology";
	        WearableTechnology wearable = entry.getValue();
			
			PreparedStatement pst = conn.prepareStatement(insertProductQurey);
			pst.setString(1,name);
			pst.setString(2,wearable.getId());
			pst.setString(3,wearable.getName());
			pst.setDouble(4,wearable.getPrice());
			pst.setString(5,wearable.getImage());
			// pst.setString(6,wearable.getRetailer());
			// pst.setString(7,wearable.getCondition());
			pst.setDouble(6,wearable.getDiscount());
			
			pst.executeUpdate();
			
			
		}
		
	}catch(Exception e)
	{
  		e.printStackTrace();
	}
} 

public static HashMap<String,Laptops> getLaptops()
{	
	HashMap<String,Laptops> hm=new HashMap<String,Laptops>();
	try 
	{
		getConnection();
		
		String selectConsole="select * from  Productdetails where ProductType=?";
		PreparedStatement pst = conn.prepareStatement(selectConsole);
		pst.setString(1,"laptop");
		ResultSet rs = pst.executeQuery();
	
		while(rs.next())
		{	Laptops con = new Laptops(rs.getString("productName"),rs.getDouble("productPrice"),rs.getString("productImage"),"I7 processor",rs.getDouble("productDiscount"));
				hm.put(rs.getString("Id"), con);
				con.setId(rs.getString("Id"));
				System.out.println(rs.getString("Id"));
				// try
				// {
				// String selectaccessory = "Select * from Product_accessories where productName=?";
				// PreparedStatement pstacc = conn.prepareStatement(selectaccessory);
				// pstacc.setString(1,rs.getString("Id"));
				// ResultSet rsacc = pstacc.executeQuery();
				// //System.out.print("assccececeec" + rsacc.getString("accessoriesName"));
				// HashMap<String,String> acchashmap = new HashMap<String,String>();
				// while(rsacc.next())
				// {    
					// if (rsacc.getString("accessoriesName") != null){
					// System.out.print("acc");
					 // acchashmap.put(rsacc.getString("accessoriesName"),rsacc.getString("accessoriesName"));
					 // con.setAccessories(acchashmap);
					// }
					 
				// }					
				// }catch(Exception e)
				// {
						// e.printStackTrace();
				// }
		}
	}
	catch(Exception e)
	{
	}
	return hm;			
}

public static HashMap<String,WearableTechnology> getWearabletechnology()
{	
	HashMap<String,WearableTechnology> hm=new HashMap<String,WearableTechnology>();
	try 
	{
		getConnection();
		
		String selectTablet="select * from  Productdetails where ProductType=?";
		PreparedStatement pst = conn.prepareStatement(selectTablet);
		pst.setString(1,"wearabletechnology");
		ResultSet rs = pst.executeQuery();
	
		while(rs.next())
		{	WearableTechnology tab = new WearableTechnology("WearableTechnology",rs.getString("productName"),rs.getDouble("productPrice"),rs.getString("productImage"),"FitnessTracker",rs.getDouble("productDiscount"));
				hm.put(rs.getString("Id"), tab);
				tab.setId(rs.getString("Id"));
		//		System.out.println(rs.getString("Id"));
		}
	}
	catch(Exception e)
	{
	}
	return hm;			
}



public static HashMap<String,SmartSpeaker> getSmartspeakers()
{	
	HashMap<String,SmartSpeaker> hm=new HashMap<String,SmartSpeaker>();
	try 
	{
		getConnection();
		
		String selectGame="select * from  Productdetails where ProductType=?";
		PreparedStatement pst = conn.prepareStatement(selectGame);
		pst.setString(1,"smartspeaker");
		ResultSet rs = pst.executeQuery();
	
		while(rs.next())
		{	SmartSpeaker game = new SmartSpeaker("SmartSpeaker",rs.getString("productName"),rs.getDouble("productPrice"),rs.getString("productImage"),"Google",rs.getDouble("productDiscount"));
				hm.put(rs.getString("Id"), game);
				game.setId(rs.getString("Id"));
		//		System.out.println(rs.getString("Id"));
		}
	}
	catch(Exception e)
	{
	}
	return hm;			
}

public static HashMap<String,Phones> getPhones()
{	
	HashMap<String,Phones> hm=new HashMap<String,Phones>();
	try 
	{
		getConnection();
		
		String selectAcc="select * from  Productdetails where ProductType=?";
		PreparedStatement pst = conn.prepareStatement(selectAcc);
		pst.setString(1,"phone");
		ResultSet rs = pst.executeQuery();
	
		while(rs.next())
		{	Phones acc = new Phones(rs.getString("productName"),rs.getDouble("productPrice"),rs.getString("productImage"),"Android",rs.getDouble("productDiscount"));
				hm.put(rs.getString("Id"), acc);
				acc.setId(rs.getString("Id"));
		//		System.out.println(rs.getString("Id"));
		}
	}
	catch(Exception e)
	{
	}
	return hm;			
}

public static String addproducts(String producttype,String productId,String productName,double productPrice,String productImage,double productDiscount,String prod)
{
	String msg = "Product is added successfully";
	try{
		
		getConnection();
		String addProductQurey = "INSERT INTO  Productdetails(ProductType,Id,productName,productPrice,productImage,productDiscount)" +
		"VALUES (?,?,?,?,?,?);";
		   
			String name = producttype;
	        			
			PreparedStatement pst = conn.prepareStatement(addProductQurey);
			pst.setString(1,name);
			pst.setString(2,productId);
			pst.setString(3,productName);
			pst.setDouble(4,productPrice);
			pst.setString(5,productImage);
			// pst.setString(6,productManufacturer);
			// pst.setString(7,productCondition);
			pst.setDouble(6,productDiscount);
			
			pst.executeUpdate();
			try{
				if (!prod.isEmpty())
				{
					String addaprodacc =  "INSERT INTO  Product_accessories(productName,accessoriesName)" +
					"VALUES (?,?);";
					PreparedStatement pst1 = conn.prepareStatement(addaprodacc);
					pst1.setString(1,prod);
					pst1.setString(2,productId);
					pst1.executeUpdate();
					
				}
			}catch(Exception e)
			{
				msg = "Error while adding the product";
				e.printStackTrace();
		
			}
			
			
		
	}
	catch(Exception e)
	{
		msg = "Error while adding the product";
		e.printStackTrace();
		
	}
	return msg;
}
public static String updateproducts(String producttype,String productId,String productName,double productPrice,String productImage,double productDiscount)
{ 
    String msg = "Product is updated successfully";
	try{
		
		getConnection();
		String updateProductQurey = "UPDATE Productdetails SET productName=?,productPrice=?,productImage=?,productDiscount=? where Id =?;" ;        			
			PreparedStatement pst = conn.prepareStatement(updateProductQurey);
			
			pst.setString(1,productName);
			pst.setDouble(2,productPrice);
			pst.setString(3,productImage);
			// pst.setString(4,productManufacturer);
			// pst.setString(5,productCondition);
			pst.setDouble(4,productDiscount);
			pst.setString(5,productId);
			pst.executeUpdate();
			
			
		
	}
	catch(Exception e)
	{
		msg = "Product cannot be updated";
		e.printStackTrace();
		
	}
 return msg;	
}
public static String deleteproducts(String productId)
{   
String msg = "Product is deleted successfully";
	try
	{
		
		getConnection();
		String deleteproductsQuery ="Delete from Productdetails where Id=?";
		PreparedStatement pst = conn.prepareStatement(deleteproductsQuery);
		pst.setString(1,productId);
		
		pst.executeUpdate();
	}
	catch(Exception e)
	{
			msg = "Proudct cannot be deleted";
	}
	return msg;
}

public HashMap<String,Product> getProductCatalog()
 {
            Product prod;
            HashMap<String,Product> productList = new HashMap<String,Product>();
            try{
                getConnection();
                
                Statement stmt=conn.createStatement();
                ResultSet rs=stmt.executeQuery("select * from Products");

                while(rs.next()){
                    prod = new Product();
                    prod.setName(rs.getString("name"));
                    prod.setPrice(rs.getDouble("price"));
                    prod.setId(rs.getString("id"));
					prod.setQuantity(rs.getInt("quantity"));
					prod.setProdOnSale(rs.getString("OnSale"));
					prod.setManuRebate(rs.getString("Rebate"));
                    productList.put(prod.getId(),prod);
                }
                rs.close();
                stmt.close();
            }catch(SQLException exception){
                exception.printStackTrace();
            }
            
            return productList;
       }

public ArrayList<Product> getProductSalesStat()
{
						 Product prod;
						 ArrayList<Product> prodSoldList = new ArrayList<Product>();
						 try{
								 getConnection();
								
								 Statement stmt=conn.createStatement();
								 ResultSet rs=stmt.executeQuery("select orderName,orderPrice,count(orderName) as items_sold,(orderPrice * count(orderName)) as TotalSales from customerorders group by orderName");
								 while(rs.next()){
										 prod = new Product();
										 prod.setName(rs.getString("orderName"));
										 prod.setPrice(rs.getDouble("orderPrice"));                                    
										 prod.setItems_Sold(rs.getInt("items_sold"));
										 prod.setTotal_Sales(rs.getDouble("TotalSales"));
										 prodSoldList.add(prod);
								 }
								 rs.close();
								 stmt.close();
						 }
						 catch(SQLException exception){
								 exception.printStackTrace();
						 }
						 return prodSoldList;
}
	 
 public ArrayList<Product> getDailySalesTransaction()
 {
 Product prod;
 ArrayList<Product> salesTransList = new ArrayList<Product>();
 try{
		 getConnection();
		 
		 Statement stmt=conn.createStatement();
		 ResultSet rs=stmt.executeQuery("select date_place,sum(orderPrice) as TotalSales from customerorders group by date_place");
		 while(rs.next()){
				 prod = new Product();
				 prod.setDate_Place(rs.getString("date_place"));
				 prod.setTotal_Sales(rs.getDouble("TotalSales"));
				 salesTransList.add(prod);
		 }
		 rs.close();
		 stmt.close();
 }
 catch(SQLException exception)
 {
		 exception.printStackTrace();
 }
 
return salesTransList;
}	 



public static HashMap<String,Product> getData()
	{
		HashMap<String,Product> hm=new HashMap<String,Product>();
		try
		{
			getConnection();
			Statement stmt=conn.createStatement();
			String selectCustomerQuery="select * from  productdetails";
			ResultSet rs = stmt.executeQuery(selectCustomerQuery);
			while(rs.next())
			{	Product p = new Product(rs.getString("Id"),rs.getString("productName"),rs.getDouble("productPrice"),rs.getString("productImage"),rs.getString("ProductType"),rs.getDouble("productDiscount"));
				hm.put(rs.getString("Id"), p);
				System.out.println(rs.getString("Id"));
			}
		}
		catch(Exception e)
		{
		e.printStackTrace();	
		}
		return hm;			
	}


	
}	