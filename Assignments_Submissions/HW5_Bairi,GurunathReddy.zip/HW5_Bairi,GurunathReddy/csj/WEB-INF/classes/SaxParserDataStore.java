
import org.xml.sax.InputSource;

import java.io.IOException;
import java.text.ParseException;
import java.util.*;
import  java.io.StringReader;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


////////////////////////////////////////////////////////////

/**************

SAX parser use callback function  to notify client object of the XML document structure. 
You should extend DefaultHandler and override the method when parsin the XML document

***************/

////////////////////////////////////////////////////////////

public class SaxParserDataStore extends DefaultHandler {
    Phones phones;
    Laptops laptops;
	SmartSpeaker smartspeakers;
	WearableTechnology wearabletechnologys;
    Accessory accessory;
    static HashMap<String,Phones> phone;
    static HashMap<String,WearableTechnology> wearabletechnology;
	static HashMap<String,Laptops> laptop;
    static HashMap<String,SmartSpeaker> smartspeaker;
    static HashMap<String,Accessory> accessories;
    String consoleXmlFileName;
	HashMap<String,String> accessoryHashMap;
    String elementValueRead;
	String currentElement="";
    public SaxParserDataStore()
	{
	}
	public SaxParserDataStore(String consoleXmlFileName) {
    this.consoleXmlFileName = consoleXmlFileName;
    phone = new HashMap<String, Phones>();
	laptop=new  HashMap<String, Laptops>();
	smartspeaker=new HashMap<String, SmartSpeaker>();
	wearabletechnology = new HashMap<String, WearableTechnology>();
	accessories=new HashMap<String, Accessory>();
	accessoryHashMap=new HashMap<String,String>();
	parseDocument();
    }

   //parse the xml using sax parser to get the data
    private void parseDocument() 
	{
        SAXParserFactory factory = SAXParserFactory.newInstance();
        try 
		{
		System.out.println("Breakpoint");
	    SAXParser parser = factory.newSAXParser();
	    parser.parse(consoleXmlFileName, this);
        } catch (ParserConfigurationException e) {
            System.out.println("ParserConfig error");
        } catch (SAXException e) {
            System.out.println("SAXException : xml not well formed");
        } catch (IOException e) {
            System.out.println("IO error");
        }
	}

   

////////////////////////////////////////////////////////////

/*************

There are a number of methods to override in SAX handler  when parsing your XML document :

    Group 1. startDocument() and endDocument() :  Methods that are called at the start and end of an XML document. 
    Group 2. startElement() and endElement() :  Methods that are called  at the start and end of a document element.  
    Group 3. characters() : Method that is called with the text content in between the start and end tags of an XML document element.


There are few other methods that you could use for notification for different purposes, check the API at the following URL:

https://docs.oracle.com/javase/7/docs/api/org/xml/sax/helpers/DefaultHandler.html

***************/

////////////////////////////////////////////////////////////
	

    @Override
    public void startElement(String str1, String str2, String elementName, Attributes attributes) throws SAXException {
	
        if (elementName.equalsIgnoreCase("laptops")) 
		{
			currentElement="laptops";
			laptops = new Laptops();
			System.out.println("Inside start element of laptop");
            laptops.setId(attributes.getValue("id"));
		}
        if (elementName.equalsIgnoreCase("phones"))
		{
			currentElement="phones";
			System.out.println("Breakpoint");
			phones = new Phones();
            phones.setId(attributes.getValue("id"));
        }
		if (elementName.equalsIgnoreCase("WearableTechnology"))
		{
			currentElement="WearableTechnology";
			wearabletechnologys = new WearableTechnology();
            wearabletechnologys.setId(attributes.getValue("id"));
        }
		
        if (elementName.equalsIgnoreCase("smartspeakers"))
		{
			currentElement="smartspeakers";
			smartspeakers = new SmartSpeaker();
			System.out.println("Breakpoint");
            smartspeakers.setId(attributes.getValue("id"));
        }
        if (elementName.equals("accessory") &&  !currentElement.equals("phones") &&  !currentElement.equals("laptops") &&  !currentElement.equals("smartspeaker"))
		{
			System.out.println("Accessory SAX");
			currentElement="accessory";
			accessory=new Accessory();
			accessory.setId(attributes.getValue("id"));
	    }


    }
	
    @Override
    public void endElement(String str1, String str2, String element) throws SAXException {
		
        if (element.equals("laptops")) {
			System.out.println("Inside end element of laptop");
			laptop.put(laptops.getId(),laptops);
			return;
        }
 
        if (element.equals("phones")) {	
			phone.put(phones.getId(),phones);
			return;
        }
		
		if (element.equals("WearableTechnology")) {	
			wearabletechnology.put(wearabletechnologys.getId(),wearabletechnologys);
			return;
        }
		
        if (element.equals("smartspeakers")) {	  
			smartspeaker.put(smartspeakers.getId(),smartspeakers);
			return;
        }
        if (element.equals("accessory") && currentElement.equals("accessory")) {
			System.out.println("Inside end element of Accessory");
			accessories.put(accessory.getId(),accessory);       
			return; 
        }
		
		//laptops with accessory
		if (element.equals("accessory") && currentElement.equals("laptops")) 
		{
			System.out.println("Inside end element of accessory");
			accessoryHashMap.put(elementValueRead,elementValueRead);
		}
      	if (element.equalsIgnoreCase("accessories") && currentElement.equals("laptops")) {
			laptops.setAccessories(accessoryHashMap);
			accessoryHashMap=new HashMap<String,String>();
			return;
		}
		
		//phones with accessory
		if (element.equals("accessory") && currentElement.equals("phones")) 
		{
			accessoryHashMap.put(elementValueRead,elementValueRead);
		}
      	if (element.equalsIgnoreCase("accessories") && currentElement.equals("phones")) {
			phones.setAccessories(accessoryHashMap);
			accessoryHashMap=new HashMap<String,String>();
			return;
		}
		
		//Smartspeaker with accessory
		
		if (element.equals("accessory") && currentElement.equals("smartspeaker")) 
		{
			System.out.println("Breakpoint");
			accessoryHashMap.put(elementValueRead,elementValueRead);
		}
      	if (element.equalsIgnoreCase("smartspeakers") && currentElement.equals("smartspeakers")) {
			smartspeakers.setAccessories(accessoryHashMap);
			accessoryHashMap=new HashMap<String,String>();
			return;
		}
		
		
		//Images tag with all type of products
        if (element.equalsIgnoreCase("image")) {
		    if(currentElement.equals("laptops"))
				laptops.setImage(elementValueRead);
        	if(currentElement.equals("phones"))
				phones.setImage(elementValueRead);
            if(currentElement.equals("smartspeakers"))
				smartspeakers.setImage(elementValueRead);
			if(currentElement.equals("WearableTechnology"))
				wearabletechnologys.setImage(elementValueRead); 
            if(currentElement.equals("accessory"))
			{
				System.out.println("Img of Acc");
				accessory.setImage(elementValueRead);  
			}				
			return;
        }
        
		//Discounts with all type of products
		if (element.equalsIgnoreCase("discount")) {
            if(currentElement.equals("laptops"))
				laptops.setDiscount(Double.parseDouble(elementValueRead));
        	if(currentElement.equals("phones"))
				phones.setDiscount(Double.parseDouble(elementValueRead));
            if(currentElement.equals("smartspeakers"))
				smartspeakers.setDiscount(Double.parseDouble(elementValueRead));
			 if(currentElement.equals("WearableTechnology"))
				wearabletechnologys.setDiscount(Double.parseDouble(elementValueRead));
			
            // if(currentElement.equals("accessory"))
				// accessory.setDiscount(Double.parseDouble(elementValueRead));          
			return;
	    }


		if (element.equalsIgnoreCase("os")) {
            if(currentElement.equals("phones"))
				phones.setos(elementValueRead);       
			return;
		}
		
		if (element.equalsIgnoreCase("manufacturer")) {
            if(currentElement.equals("smartspeakers"))
				smartspeakers.setRetailer(elementValueRead); 
			if(currentElement.equals("accessory"))
				accessory.setRetailer(elementValueRead);
				
			return;
		}
		
		if (element.equalsIgnoreCase("type")) {
            if(currentElement.equals("WearableTechnology"))
				wearabletechnologys.setType(elementValueRead);       
			return;
		}
		
		
		if (element.equalsIgnoreCase("processor")) {
            if(currentElement.equals("laptops"))
				laptops.setProcessor(elementValueRead);       
			return;
		}

		//Name of different product catalogs
        if (element.equalsIgnoreCase("name")) {
			if(currentElement.equals("phones"))
				phones.setName(elementValueRead);
            if(currentElement.equals("laptops"))
			{
				System.out.println("Inside laptop SAX");
				laptops.setName(elementValueRead);
			}
            if(currentElement.equals("smartspeakers"))
				smartspeakers.setName(elementValueRead);
            if(currentElement.equals("accessory"))
				accessory.setName(elementValueRead);
			 if(currentElement.equals("WearableTechnology"))
				wearabletechnologys.setName(elementValueRead);
			
			return;
	    }
		
		//price of different product catalog
        if(element.equalsIgnoreCase("price")){
			if(currentElement.equals("laptops"))
				laptops.setPrice(Double.parseDouble(elementValueRead));
        	if(currentElement.equals("phones"))
				phones.setPrice(Double.parseDouble(elementValueRead));
            if(currentElement.equals("smartspeakers"))
				smartspeakers.setPrice(Double.parseDouble(elementValueRead));
            if(currentElement.equals("accessory"))
				accessory.setPrice(Double.parseDouble(elementValueRead));  
			if(currentElement.equals("WearableTechnology"))
				wearabletechnologys.setPrice(Double.parseDouble(elementValueRead));  			
			return;
        }

	}
	//get each element in xml tag
    @Override
    public void characters(char[] content, int begin, int end) throws SAXException {
	
        elementValueRead = new String(content, begin, end);
    }


    /////////////////////////////////////////
    // 	     Kick-Start SAX in main       //
    ////////////////////////////////////////
	
//call the constructor to parse the xml and get product details
 public static void addHashmap() {
		
		String TOMCAT_HOME = System.getProperty("catalina.home");
		System.out.println(TOMCAT_HOME);
		new SaxParserDataStore(TOMCAT_HOME+"\\webapps\\csj\\ProductCatalog.xml");
    } 
}
