import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AccessoryList")

public class AccessoryList extends HttpServlet {


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		String CategoryName = request.getParameter("maker");
		HashMap<String, Accessory> hm = new HashMap<String, Accessory>();
		//HashMap<String, Laptops> hm1 = new HashMap<String, Laptops>();
		
			if(CategoryName.equals("Samsung"))
			{
				
				System.out.println("outside Samsung Accessory");
				for(Map.Entry<String,Accessory> entry : SaxParserDataStore.accessories.entrySet())
				{	
					if(entry.getValue().getRetailer().equals("Samsung"))
					{
					System.out.println("Samsung Accessory");
					 hm.put(entry.getValue().getId(),entry.getValue());
					}
				}
				
			}
			else if(CategoryName.equals("Google"))
			{	
				for(Map.Entry<String,Accessory> entry : SaxParserDataStore.accessories.entrySet())
				{	
				  if(entry.getValue().getRetailer().equals("Google"))
				 { 
					System.out.println("Breakpoint");
					hm.put(entry.getValue().getId(),entry.getValue());
				 }
				}
			}
			
			
//		Console console = hm.get(ConsoleName);
				
		/* Header, Left Navigation Bar are Printed.

		All the Accessories and Accessories information are dispalyed in the Content Section

		and then Footer is Printed*/

		
		Utilities utility = new Utilities(request,pw);
		utility.printHtml("Header.html");
		utility.printHtml("LeftNav.html");
		pw.print("<div id='content' style='margin-left:30%'><div class='post'><h2 class='title meta'>");
		pw.print("<a style='font-size: 24px;'>"+CategoryName+" Accessories List </a>");
		pw.print("</h2><table id='bestseller'>");
		int i = 1; int size= 2;
		for(Map.Entry<String, Accessory> entry : hm.entrySet())
		{
				Accessory accessory = entry.getValue();
				if(i%1==1) pw.print("<tr>");
				System.out.print(size);
				pw.print("<td><div id='shop_item'>");
				pw.print("<b><h3>"+accessory.getName()+"</h3></b>");
				pw.print("<strong>"+accessory.getPrice()+"$</strong><ul>");
				pw.print("<li id='item'><img src='images/accessories/"+accessory.getImage()+"' height='130' width='130' alt='' /></li>");
				pw.print("<li><form method='post' action='Cart'>" +
						"<input type='hidden' name='name' value='"+entry.getKey()+"'>"+
						"<input type='hidden' name='type' value='accessories'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value='"+accessory.getName()+"'>"+
						"<h5>Buy extended warranty</h5>"+
						"<select size='1' style='width:10%'>"+
						"<option style='font-size: 15px;' value='no'>No</option>"+
						"<option style='font-size: 15px;' value='yes'>Yes</option>"+
						"</select>"+
						"<br/>"+
						"<br/>"+
						"<input type='submit' class='btnbuy' value='Buy Now'></form></li></form></li>");
						pw.print("<li><form method='post' action='WriteReview'>"+"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
						"<input type='hidden' name='type' value='accessories'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value='"+accessory.getName()+"'>"+
						"<input type='hidden' name='price' value='"+accessory.getPrice()+"'>"+
						"<input type='submit' value='WriteReview' class='btnreview'></form></li>");
				pw.print("<li><form method='post' action='ViewReview'>"+"<input type='hidden' name='name' value='"+accessory.getName()+"'>"+
						"<input type='hidden' name='type' value='accessories'>"+
						"<input type='hidden' name='maker' value='"+CategoryName+"'>"+
						"<input type='hidden' name='access' value='"+accessory.getName()+"'>"+
						"<input type='submit' value='ViewReview' class='btnreview'></form></li>");

		
				pw.print("</ul></div></td>");
				if(i%1==0 || i == size) pw.print("</tr>");
				i++;
			
				
		}	
		pw.print("</table></div></div></div>");		
		utility.printHtml("Footer.html");
	}
}
