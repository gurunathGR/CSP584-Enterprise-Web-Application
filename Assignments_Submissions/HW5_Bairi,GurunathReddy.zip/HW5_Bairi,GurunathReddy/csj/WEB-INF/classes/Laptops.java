import java.util.*;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Laptops")


public class Laptops extends HttpServlet{
	private String id;
	private String name;
	private double price;
	private String image;
	private String processor;
	// private String condition;
	private double discount;
	HashMap<String,String> accessories;
	
	public Laptops(String name, double price, String image, String processor, double discount){
		this.name=name;
		this.price=price;
		this.image=image;
		this.processor=processor;
		// this.condition=condition;
		this.discount = discount;
		this.accessories=new HashMap<String,String>();
		// this.retailer = retailer;
	}
	HashMap<String,String> getAccessories() {
		return accessories;
		}
	public Laptops(){
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		System.out.println(id);
		this.id = id;
	}
		

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getProcessor() {
		return processor;
	}
	public void setProcessor(String processor) {
		this.processor = processor;
	}

	// public String getCondition() {
		// return condition;
	// }

	// public void setCondition(String condition) {
		// this.condition = condition;
	// }
	
	public void setAccessories( HashMap<String,String> accessories) {
		this.accessories = accessories;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
}
