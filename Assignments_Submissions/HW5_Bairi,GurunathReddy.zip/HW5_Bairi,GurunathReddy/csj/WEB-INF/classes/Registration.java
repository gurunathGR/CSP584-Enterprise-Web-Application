import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;

@WebServlet("/Registration")

public class Registration extends HttpServlet {
	private String error_msg;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		displayRegistration(request, response, pw, false);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities utility = new Utilities(request, pw);

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String repassword = request.getParameter("repassword");
		String usertype = "customer";
		if(!utility.isLoggedin())
			usertype = request.getParameter("usertype");

		

		if(!password.equals(repassword))
		{
			error_msg = "Passwords doesn't match!";
		}
		else
		{
			HashMap<String, User> hm=new HashMap<String, User>();
			//String TOMCAT_HOME = System.getProperty("catalina.home");

			//get the user details from file 

			// try
			// {
 			 // FileInputStream fileInputStream = new FileInputStream(new File(TOMCAT_HOME+"\\webapps\\csj\\UserDetails.txt"));
			 // ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);	      
			 // hm= (HashMap)objectInputStream.readObject();
			// }
			// catch(Exception e)
			// {
				
			// }
			
			try
			{
				hm=MySqlDataStoreUtilities.selectUser();
			}
			catch(Exception e)
			{
				
			}


			

			if(hm.containsKey(username))
				error_msg = "Username already exist as " + usertype;
			else
			{
				// User user = new User(username,password,usertype);
				// hm.put(username, user);
			    // FileOutputStream fileOutputStream = new FileOutputStream(TOMCAT_HOME+"\\webapps\\csj\\UserDetails.txt");
        		// ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
           	 	// objectOutputStream.writeObject(hm);
				// objectOutputStream.flush();
				// objectOutputStream.close();       
				// fileOutputStream.close();
				// HttpSession session = request.getSession(true);				
				// session.setAttribute("login_msg", "Your "+usertype+" account has been created. Please login");
				// if(!utility.isLoggedin()){
					// response.sendRedirect("Login"); return;
				// } else {
					// response.sendRedirect("Account"); return;
				// }
				
				
				User user = new User(username,password,usertype);
				hm.put(username, user);
				MySqlDataStoreUtilities.insertUser(username,password,repassword,usertype);					
				HttpSession session = request.getSession(true);				
				session.setAttribute("login_msg", "Your "+usertype+" account has been created. Please login");
				if(!utility.isLoggedin()){
					response.sendRedirect("Login"); return;
				} else {
					response.sendRedirect("Account"); return;
				}
				
			}
		}

	
		if(utility.isLoggedin()){
			HttpSession session = request.getSession(true);				
			session.setAttribute("login_msg", error_msg);
			response.sendRedirect("Account"); return;
		}
		displayRegistration(request, response, pw, true);
		
	}
 
	
	protected void displayRegistration(HttpServletRequest request,
			HttpServletResponse response, PrintWriter pw, boolean error)
			throws ServletException, IOException {
		Utilities utility = new Utilities(request, pw);
		utility.printHtml("Header.html");
		pw.print("<div class='post' style='float: none; width: 100%'>");
		pw.print("<h2 class='logo' align='center'>Registration</h2>"
				+ "<div class='entry'>"
				+ "<div style='width:400px; margin:25px; margin-left: auto;margin-right: auto;'>");
		if (error)
			pw.print("<h4 style='color:red'>"+error_msg+"</h4>");
		pw.print("<form class='login-form-1' method='post' action='Registration'>"
				+ "<div class='form-group'><label class='sr-only'>Username</label>"
				+"<input type='text' name='username' value='' class='form-control' required placeholder='UserName'></input></div>"
				+ "<div class='form-group'><label class='sr-only'>Password</label> "
				+"<input type='password' name='password' value='' class='form-control' placeholder='Password' required></input></div>"
				+ "<div class='form-group'><label class='sr-only'>Re-PasswordPassword</label> "
				+"<input type='password' name='repassword' value='' class='form-control' placeholder='Password' required></input></div>"
				+"<div class='form-group'><label>UserType</label> <select name='usertype' class='form-control'><option value='customer' selected>Customer</option><option value='retailer'>Store Manager</option><option value='manager'>Salesman</option></select> </div>"
				+ "<div> <input type='submit' name='ByUser' class='login-button' value='Create Account'><i class='fa fa-chevron-right'></i></input></div>"
				+ "</form>" + "</div></div></div>");
		utility.printHtml("Footer.html");
	}
}
