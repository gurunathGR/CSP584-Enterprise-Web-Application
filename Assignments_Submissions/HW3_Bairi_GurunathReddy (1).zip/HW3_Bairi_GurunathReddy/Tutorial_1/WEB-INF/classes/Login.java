import java.io.*;
import java.io.PrintWriter;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Login")

public class Login extends HttpServlet {
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String usertype = request.getParameter("usertype");
		HashMap<String, User> hm=new HashMap<String, User>();
		String TOMCAT_HOME = System.getProperty("catalina.home");
	
		// try
		// {		
          // FileInputStream fileInputStream = new FileInputStream(new File(TOMCAT_HOME+"\\webapps\\csj\\UserDetails.txt"));
          // ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);	      
		  // hm = (HashMap)objectInputStream.readObject();
		// }
		// catch(Exception e)
		// {
				
		// }
		
		try
		{	
			hm=MySqlDataStoreUtilities.selectUser();
		}
		catch(Exception e)
		{
				
		}
		User user = hm.get(username);
		if(user!=null)
		{
		 String user_password = user.getPassword();
		 if (password.equals(user_password)) 
			{
			HttpSession session = request.getSession(true);
			session.setAttribute("username", user.getName());
			session.setAttribute("usertype", user.getUsertype());
			if(session.getAttribute("usertype").equals("manager"))
			{
			System.out.println("Salesman");
			response.sendRedirect("ViewOrder");
			}
			if(session.getAttribute("usertype").equals("retailer"))
			{
				System.out.println("Manager View");
			response.sendRedirect("ManagerHome");
			}
			
			else{
				System.out.println("Customer");
			response.sendRedirect("Home");
			}
			return;
			}
		}
		displayLogin(request, response, pw, true);
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		displayLogin(request, response, pw, false);
	}


	
	protected void displayLogin(HttpServletRequest request,
			HttpServletResponse response, PrintWriter pw, boolean error)
			throws ServletException, IOException {

		Utilities utility = new Utilities(request, pw);
		utility.printHtml("Header.html");
		pw.print("<div class='post' style='float: none; width: 100%'>");
		pw.print("<h2 class='logo' align='center'>Login Page</h2>"
				+ "<div class='entry'>"
				+ "<div style='width:400px; margin:25px; margin-left: auto;margin-right: auto;'>");
		if (error)
			pw.print("<h4 style='color:red'>Username pasword Incorrect</h4>");
		HttpSession session = request.getSession(true);
		if(session.getAttribute("login_msg")!=null){			
			pw.print("<h4 style='color:green'>"+session.getAttribute("login_msg")+"</h4>");
			session.removeAttribute("login_msg");
		}
		pw.print("<div class='login-form-1'> "
				+ "<form id='login-form'  method='post' action='Login'>"
				+ "<div class='form-group'><label class='sr-only'>Username</label>"
				+"<input type='text' name='username' value='' class='form-control' required placeholder='UserName'></input></div>"
				+ "<div class='form-group'><label class='sr-only'>Password</label> "
				+"<input type='password' name='password' value='' class='form-control' placeholder='Password' required></input></div>"
				+"<div class='form-group'><label>UserType</label> <select name='usertype' class='form-control'><option value='customer' selected>Customer</option><option value='retailer'>Store Manager</option><option value='manager'>Salesman</option></select> </div>"
				+ "</div> <input type='submit' class='login-button' value='Login'><i class='fa fa-chevron-right'></i></input>"
				+ "<strong><a class='' href='Registration' style='float: right;height: 20px margin: 20px;'>New User? Create New Account</a></strong>"
				+ "</form>" 
				+ "</div></div></div>");
		utility.printHtml("Footer.html");
	}

}
  