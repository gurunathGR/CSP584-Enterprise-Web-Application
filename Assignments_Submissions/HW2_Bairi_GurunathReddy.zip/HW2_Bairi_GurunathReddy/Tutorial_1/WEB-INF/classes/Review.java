import java.io.IOException;
import java.io.*;


/* 
	Review class contains class variables username,productname,reviewtext,reviewdate,reviewrating

	Review class has a constructor with Arguments username,productname,reviewtext,reviewdate,reviewrating
	  
	Review class contains getters and setters for username,productname,reviewtext,reviewdate,reviewrating
*/

public class Review implements Serializable{
	private String productName;
	private String userName;
	private String productType;
	private String productMaker;
	private String reviewRating;
	private String reviewDate;
	private String reviewText;
	private String retailerpin;
	private String price;
	private String retailercity;
	private String State;
	private String Sale;
	private String UserId;
    private String UserAge;
    private String UserGender;
    private String UserOcc;
    private String ManR;
    private String ManN;
	
	public Review (String productName,String userName,String productType,String productMaker,String reviewRating,String reviewDate,String reviewText,String retailerpin,String price,String retailercity,String UserAge,String UserId,String UserGender,String UserOcc,String ManR,String ManN,String State,String Sale){
		this.productName=productName;
		this.userName=userName;
		this.productType=productType;
		this.productMaker=productMaker;
	 	this.reviewRating=reviewRating;
		this.reviewDate=reviewDate;
		this.State=State;
		this.Sale=Sale;
	 	this.reviewText=reviewText;
		this.retailerpin=retailerpin;
		this.price=price;
		this.UserId=UserId;
		this.UserAge=UserAge;
		this.UserGender=UserGender;
		this.UserOcc=UserOcc;
		this.ManR=ManR;
		this.ManN=ManN;
		this.retailercity= retailercity;
	}

	public Review(String productName, String retailerpin, String reviewRating, String reviewText,String UserAge) {
       this.productName = productName;
       this.retailerpin = retailerpin;
       this.reviewRating = reviewRating;
       this.reviewText = reviewText;
       this.UserAge= UserAge;
       
    }

	public String getProductName() {
		return productName;
	}
	public String getUserName() {
		return userName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductMaker() {
		return productMaker;
	}

	public void setProductMaker(String productMaker) {
		this.productMaker = productMaker;
	}

	public String getReviewRating() {
		return reviewRating;
	}

	public String getReviewText() {
		return reviewText;
	}
	public void setReviewText(String reviewText) {
		this.reviewText = reviewText;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setReviewRating(String reviewRating) {
		this.reviewRating = reviewRating;
	}
	public String getReviewDate() {
		return reviewDate;
	}

	public void setReviewDate(String reviewDate) {
		this.reviewDate = reviewDate;
	}
    
		public String getRetailerPin() {
		return retailerpin;
	}

	public void setRetailerPin(String retailerpin) {
		this.retailerpin = retailerpin;
	}
			public String getRetailerCity() {
		return retailercity;
	}

	public void setRetailerCity(String retailercity) {
		this.retailercity = retailercity;
	}
	
			public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getUserAGE() {
	return UserAge;
}

public void setUserAGE(String userage) {
	this.UserAge = userage;
}

public String getUserID() {
	return UserId;
}

public void setUserID(String userid) {
	this.UserId = userid;
}

public String getUserGENDER() {
	return UserGender;
}

public void setUserGENDER(String usergender) {
	this.UserGender = usergender;
}

public String getUserOCCUPATION() {
	return UserOcc;
}

public void setUserOCCUPATION(String userocc) {
	this.UserOcc = userocc;
}

public String getMANR() {
	return ManR;
}

public void setMANR(String manr) {
	this.ManR = manr;
}

public String getMANN() {
	return ManN;
}

public void setMANN(String mann) {
	this.ManN = mann;
}

public String getSTATE() {
	return State;
}

public void setState(String state) {
	this.State = state;
}


public String getSALE() {
	return Sale;
}

public void setSALE(String sale) {
	this.Sale = sale;
}



}
